<h1 align="center">📺 إضافات عربية لـ Cloudstream</h1>
<h3 align="center">
إضافات عربية مصنوعة لكم يا غوالي — من إنتاجي الشخصي لتجربة مشاهدة أسهل وأمتع للأفلام والمسلسلات بالعربية.  
هذه الإضافات تهدف لتجميع أفضل المصادر العربية في مكان واحد، لتتمكن من الاستمتاع بالمحتوى بسهولة وسلاسة.
</h3>

<p align="center">
✨ **سهلة الاستخدام • عملية • خفيفة الوزن • تجربة سلسة**  
🎬 تدعم جميع أنواع الأفلام والمسلسلات مع التركيز على تجربة مشاهدة ممتعة.
</p>

<h2>⬇️  انسخ الرابط والصقه في التطبيق او اضغط على الصورة لتحميل الإضافات</h2>
<p align="left">
  </a> https://raw.githubusercontent.com/Abodabodd/re-3arabi/refs/heads/main/repo
</p>
<p align="left">
  <a href="https://abodabodd.github.io/testpage/">
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbrCPMjoDiORDnpcSxcPa6g-7bWW31r6-BLQ&s" />
  </a>
</p>


<h2>🌟 الهدف</h2>
<ul>
<li>📌 توفير محتوى عربي مناسب وسهل الوصول.</li>
<li>🚀 تحسين تجربة المشاهدة على تطبيق Cloudstream.</li>
<li>🤝 مشاركة المجتمع العربي بملحقات مفتوحة قابلة للتطوير.</li>
</ul>

<h2>🛠️ المشاركة</h2>
<ul>
<li>إذا أعجبتك هذه الإضافات يمكنك:</li>
<ul>
<li>✅ استخدامها مباشرة.</li>
<li>✏️ تعديلها بما يناسبك.</li>
<li>💡 المساهمة باقتراحات أو تحسينات.</li>
</ul>
</ul>

<h2>⚖️ الحقوق</h2>
<p>📝 حقوق التعديل والاستخدام مفتوحة لجميع المستخدمين.</p>

</p>
<h2>⚖️ DMCA Disclaimer</h2>
<p>
We hereby issue this notice to clarify that these extensions function similarly to a standard web browser by fetching video files from the internet.
</p>
<ul>
<li>❌ No content is hosted by this repository or the Cloudstream 3 application.</li>
<li>🌐 Any content accessed is hosted by third-party websites.</li>
<li>👤 Users are solely responsible for their usage and must comply with their local laws.</li>
<li>📩 If you believe content is violating copyright laws, please contact the actual file hosts, not the developers of this repository or the Cloudstream 3 app.</li>
</ul>

---

<p align="center">
💖 **استمتع بالمشاهدة وشارك التجربة مع الأصدقاء!**
</p>











